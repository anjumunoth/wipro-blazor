﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using MyFirstWebAssemblyProject.Client.Shared;
using Microsoft.AspNetCore.Components;


namespace MyFirstWebAssemblyProject.Client.Pages
{
    public class BookBase: ComponentBase
    {
       
    }
}
