﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using MyFirstWebAssemblyProject.Client.Shared;

namespace MyFirstWebAssemblyProject.Client.Services
{
    public interface IBookInterface
    {
        public List<Books> GetAllBooks();
        public Books GetBook(string BId);
        public bool AddNewBook(Books obj);
        public bool EditBook(Books obj);
        public bool DeleteBook(string BId);

    }
    public class BookServices : IBookInterface
    {
        public List<Books> BooksList;
        
        public BookServices()
        {
            BooksList = new List<Books>();
            BooksList.Add(new Books("B101", "Alchemist", "Paul coelho", 567));
            BooksList.Add(new Books("B102", "Adventures of Sherlock Holmes", "Arthur Conan Doyle", 19879));
            BooksList.Add(new Books("B103", "Harry Potter", "JK Rowling", 789));
            BooksList.Add(new Books("B104", "If Tomorrow comes", "Sidney Sheldon", 4567));
            BooksList.Add(new Books("B105", "Life of Pi", "Yann Martel", 67890));


        }
        public List<Books> GetAllBooks() => BooksList;
        public bool AddNewBook(Books obj)
        {
            int pos = BooksList.FindIndex(book => book.BookId == obj.BookId);
            if (pos < 0)
            {

                BooksList.Add(obj);
                return true;
            }
            else
                return false;


        }
        public bool EditBook(Books obj)
        {
            int pos = BooksList.FindIndex(book => book.BookId == obj.BookId);
            if (pos >= 0)
            {
                BooksList[pos] = obj;
                return true;
            }
            else
                return false;
        }

        public Books GetBook(string BId)
        {
            Books bookObj=BooksList.Find(book => book.BookId == BId);
            Console.WriteLine("Book Details in Get Book in BookServices" + bookObj);
            if (bookObj != null)
            {
                Books bookObjClone = (Books)bookObj.Clone();
                return bookObjClone;
            }
            else
                return bookObj;
        }
        public bool DeleteBook(string BId)
        {
            int pos = BooksList.FindIndex(book => book.BookId == BId);
            if (pos >= 0)
            {
                BooksList.RemoveAt(pos);
                return true;
            }
            else
                return false;
        }


    }
}
