﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace MyFirstWebAssemblyProject.Client.Shared
{
    public class Books:ICloneable
    {
        public string BookId { get; set; }
        public string BookName { get; set; }
        public string Author { get; set; }
        public float Price { get; set; }

        public Books(string bookId, string bookName, string author, float price)
        {
            BookId = bookId;
            BookName = bookName;
            Author = author;
            Price = price;
        }
        public Books() { }

        public override bool Equals(object obj)
        {
            return base.Equals(obj);
        }

        public override int GetHashCode()
        {
            return base.GetHashCode();
        }

        public override string ToString()
        {
            string str = $"Book Id : {BookId}; Book Name : {BookName}; Author : {Author}; Price :{Price}";
            return str;
        }
        public object Clone()
        {
            var cloneObj = this.MemberwiseClone();
            return cloneObj;
        }

    }
}
