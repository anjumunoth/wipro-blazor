﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace DiExample.Services
{
    public interface ISingletonService
    {
        Guid ServiceId { get; set; }
    }
    public interface ITransientService
    {
        Guid ServiceId { get; set; }
    }
    public interface IScopedService
    {
        Guid ServiceId { get; set; }
    }

    public class MySingletonService:ISingletonService
    {
        public Guid ServiceId { get; set; }
        public MySingletonService()
        {
            ServiceId = Guid.NewGuid();
        }
    }

    public class MyTransientService : ITransientService
    {
        public Guid ServiceId { get; set; }
        public MyTransientService()
        {
            ServiceId = Guid.NewGuid();
        }
    }

    public class MyScopedService : IScopedService
    {
        public Guid ServiceId { get; set; }
        public MyScopedService()
        {
            ServiceId = Guid.NewGuid();
        }
    }



    public class MyServices
    {
    }
}
