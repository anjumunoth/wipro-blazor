﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace MyFirstWebAssemblyProject.Client.Shared
{
    public class Employee
    {
        public int EmpId { get; set; }
        public string Name { get; set; }
        public int Salary { get; set; }

        public Employee(int empId, string name, int salry)
        {
            EmpId = empId;
            Name = name;
            Salary = salry;
        }
        public Employee()
        {

        }
        public override string ToString()
        {
            string str = $"EmpId : {EmpId}; Name: {Name}; Salary : {Salary}";
            return str;
        }



    }

}
