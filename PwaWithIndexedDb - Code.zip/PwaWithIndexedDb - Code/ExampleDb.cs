﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;
using Blazor.IndexedDB.Framework;
using Microsoft.JSInterop;

namespace PwaWithIndexedDb
{
    public class ExampleDb : IndexedDb
    {
        public ExampleDb(IJSRuntime jSRuntime, string name, int version) : base(jSRuntime, name, version)
        {

        }
        public IndexedSet<Employee> EmployeeTable{get;set;}
    }

    public class Employee
    {
        [Key]
        public long Id { get; set; }
        [Required]
        public string EmpName { get; set; }

    }
}
