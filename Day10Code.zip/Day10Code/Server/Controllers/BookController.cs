﻿using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using SecondWebAssemblyProject.Server.Services;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace SecondWebAssemblyProject.Server.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class BookController : ControllerBase
    {
        private IBookInterface Bs;
        public BookController(IBookInterface bs)
        {
            Bs = bs;
        }
        // GET: api/<BookController>
        [HttpGet]
        public List<Books> Get()
        {
            //connect with the database and give the select : select * from books;
            return Bs.GetAllBooks();
        }

        // GET api/<BookController>/5
        [HttpGet("{id}")]
        public ActionResult<Books> Get(string id)
        {
            Books book=Bs.GetBook(id);
            if (book != null)
                return Ok(book);
            else
                return StatusCode(400, new Books());
            
        }

        // POST api/<BookController>
        [HttpPost]
        public ActionResult<Books> Post([FromBody] Books obj)
        {
            bool result=Bs.AddNewBook(obj);
            if (result)
                return Ok(obj);
            else
                return StatusCode(400,new Books());
        }

        // PUT api/<BookController>/5
        [HttpPut("{id}")]
        public ActionResult<Books> Put(string id, [FromBody] Books obj)
        {
            bool result=Bs.EditBook(obj);
            if (result)
                return Ok(obj);
            else
                return StatusCode(403, new Books());
        }

        // DELETE api/<BookController>/5
        [HttpDelete("{id}")]
        public void Delete(int id)
        {
        }
    }
}
