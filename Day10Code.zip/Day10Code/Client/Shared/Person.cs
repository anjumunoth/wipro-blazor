﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;
using SecondWebAssemblyProject.Client.Shared;


namespace SecondWebAssemblyProject.Client.Shared
{
    public class Person
    {

        [Required]
        public int PersonId { get; set; }
        [Required]
        public string PersonName { get; set; }
        [Range(18,80,ErrorMessage ="Age should be between 18 and 80")]
        public int Age { get; set; }
        public DateTime DateOfBirth { get; set; }
        public string Gender { get; set; }
        public Countries Country { get; set; } = Countries.India;
        [EmailDomainValidation(AllowedDomain ="wipro.com")]
        public string Email { get; set; }

        public string DepartmentId { get; set; }

        public string Password { get; set; }
        [CompareProperty]
        public string ConfirmPassword { get; set; }

    }

    public enum Countries { India, USA, Australia}
}
