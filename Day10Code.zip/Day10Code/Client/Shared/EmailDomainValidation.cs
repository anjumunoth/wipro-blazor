﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace SecondWebAssemblyProject.Client.Shared
{
    public class EmailDomainValidation: ValidationAttribute
    {
        public string AllowedDomain { get; set; }
        protected override  ValidationResult IsValid(object value, ValidationContext validationContext)
        {
            //anjumunoth@gmail.com
            string[] str1=value.ToString().Split('@');
            if(str1[1].ToUpper() == AllowedDomain.ToUpper())
            {
                return null;

            }
            return new ValidationResult($"Domain name must be {AllowedDomain}",new[] { validationContext.MemberName });

            
        }
    }
}
