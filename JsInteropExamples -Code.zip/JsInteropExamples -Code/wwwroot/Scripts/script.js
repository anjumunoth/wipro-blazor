﻿function sumNumbers(n1, n2) {
    return n1 + n2;
}

function changeColor(id) {
    var element = document.getElementById(id);// null
    element.style.backgroundColor = "pink";//error
    
}

function setFocusForUsername(elementRef) {
    elementRef.focus();
}


function workWithJquery() {
    $(document).ready(() => {
        $("#my_para").mouseenter(function (e) {
            $(this).css("background-color", "cyan");
        })
        $("#my_para").mouseover(function (e) {
            $(this).css("background-color", "cyan");
        })

        $("#my_para").mouseleave(function (e) {
            $(this).css("background-color", "pink");

       
    })
   
    })
}

function addRowToTable(rowRef,firstName, lastName) {
    var trElement = document.createElement("tr");

    var cell1 = document.createElement("td");
    var cell2 = document.createElement("td");

    cell1.innerText = firstName;
    cell2.innerText = lastName;

    trElement.append(cell1);
    trElement.append(cell2);
    rowRef.append(trElement);


}


function startGeneration(componentRef) {
    var clearIntervalId=setInterval(() => {
        var randomNumber = Math.random();
        console.log("Random number generated in js" + randomNumber);
        componentRef.invokeMethodAsync("LoadData", randomNumber.toString());
    }, 1000);
    return clearIntervalId;
}

function stopGeneration(clearIntervalId) {
    console.log("stop generation called");
    clearInterval(clearIntervalId);
}

async function calljsInvokectr() {
    await DotNet.invokeMethodAsync("JsInteropExamples","MyStaticMethod");
    console.log("calljs called");
}

console.log("Blazor not started");
Blazor.start({})
    .then(() => {
        // initial configuration settings
        // call any static methods of .net
        // call any normal method of any component
        // will be happening only once
        // create some resource 
        // connect with 3rd part api for eg maps
        // put some default data into the indexeddb
        //If its is a server project, in _host.html add the attr "autostart"
        //limitation: use it only once ; use it in multiple js files
        console.log("blazor is starting");
    })