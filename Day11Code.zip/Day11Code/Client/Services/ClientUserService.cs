﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace AuthenticationExample1.Client.Services
{
    public interface IClientUser
    {
        public bool ReturnLoggedInStatus();
        public void setLoggedOut();
        public void setLoggedIn();
    }
    public class ClientUserService:IClientUser
    {
        public bool IsLoggedIn { get; set; }

        public ClientUserService()
        {
            IsLoggedIn = false;
        }

        public bool ReturnLoggedInStatus()
        {
            return IsLoggedIn;
        }

        public void setLoggedOut()
        {
            IsLoggedIn = false;
        }

        public void setLoggedIn()
        {
            IsLoggedIn = true;
        }
    }
}
