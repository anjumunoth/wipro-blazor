﻿using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using AuthenticationExample1.Server.Services;
using AuthenticationExample1.Shared;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace AuthenticationExample1.Server.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class UserController : ControllerBase
    {
        IUserInterface Us;
        public UserController(IUserInterface us)
        {
            Us = us;
        }
        // GET: api/<UserController>
        [HttpGet]
        public IEnumerable<string> Get()
        {
            return new string[] { "value1", "value2" };
        }

        // GET api/<UserController>/asha
        [HttpGet("{username}")]
        public ActionResult<bool> Get(string username)
        {
            bool result=Us.CheckIfUserNameExists(username);
            if (result)
            {
                return Ok(true);
            }
            else
                return Ok( false);
            
        }

        // POST api/<UserController>
        [HttpPost]
        public ActionResult<bool> Post([FromBody] Users user)
        {
            bool result = Us.SaveUser(user);

            if (result)
            {
                return Ok(true);
            }
            else
            {
                return StatusCode(403, false);
            }
        }

        // PUT api/<UserController>/5
        [HttpPut("{id}")]
        public void Put(int id, [FromBody] string value)
        {
        }

        // DELETE api/<UserController>/5
        [HttpDelete("{id}")]
        public void Delete(int id)
        {
        }
    }
}
