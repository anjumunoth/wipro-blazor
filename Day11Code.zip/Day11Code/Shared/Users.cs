﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;

namespace AuthenticationExample1.Shared
{
    public class Users
    {
        [Required]
        public string Username { get; set; }

        [Required]
        public string Password { get; set; }

        [CompareProperty("Password", ErrorMessage = "Password and Confirm Password must match")]
        public string ConfirmPassword { get; set; }
    }
}
