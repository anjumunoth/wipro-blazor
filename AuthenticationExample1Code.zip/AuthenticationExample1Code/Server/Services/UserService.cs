﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using AuthenticationExample1.Shared;

namespace AuthenticationExample1.Server.Services
{
    public interface IUserInterface
    {
        public List<Users> GetAllUsers();
        public bool CheckUserNameAndPassword(string username, string password);

        public bool CheckIfUserNameExists(string username);
        public bool SaveUser(Users User);
    }
    public class UserService:IUserInterface
    {
        List<Users> UsersList;
        public UserService()
        {
            UsersList = new List<Users>()
            {
                new Users() { Username = "asha", Password = "User@1234" },
                new Users() { Username = "sara", Password = "User@1234" },
                new Users() { Username = "tara", Password = "User@1234" },
                new Users() { Username = "lara", Password = "User@1234" },
            };
        }
        public List<Users> GetAllUsers()
        {
            return UsersList;
            
        }

        public bool CheckUserNameAndPassword(string username, string password)
        {
            int pos=UsersList.FindIndex(item => (item.Username == username && item.Password == password));
            if (pos >= 0)
                return true;
            else
                return false;
        }

        public bool CheckIfUserNameExists(string username)
        {
            int pos = UsersList.FindIndex(item => (item.Username == username ));
            if (pos >= 0)
                return true;
            else
                return false;
        }
        public bool SaveUser(Users User)
        {
            try
            {
                UsersList.Add(User);
                return true;
            }
            catch
            {
                return false;
            }

        }
    }
}
