﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Components;
using MyFirstWebAssemblyProject.Client.Shared;

namespace MyFirstWebAssemblyProject.Client.Pages
{
    public class HomeBase:ComponentBase
    {
        public List<Products> ProductList;
        public List<Cart> CartList;

        public bool ShowCart { get; set; } = false;
        protected override void OnInitialized()
        {
            ProductList = new List<Products>();
            ProductList.Add(new Products(101, "Huawei Mate 40 ", 12345, 12, "Huawei Mate 40 mobile", "images/HuaweiMate40.jpg"));
            ProductList.Add(new Products(102, "Apple Iphone 12 Pro ", 123456, 7, "Apple Iphone 12 Pro mobile", "images/Iphone12Pro.jpg"));
            ProductList.Add(new Products(103, "Samsung note 20 ", 56000, 5, "Samsung note 20 mobile", "images/SamsungGalaxy20.jpg"));
            ProductList.Add(new Products(104, "Vivo V 20 ", 34000, 10, "Vivo V 20 mobile", "images/VivoV20.jpg"));
            ProductList.Add(new Products(105, "Oppo A 31", 24000, 2, "Oppo A 31mobile", "images/OppoA31.jpg"));
            CartList = new List<Cart>();
        }

        public void ShowCartEventHandler()
        {
            ShowCart = true;
        }
        public void onSendDataFromPDTohomeEventHandler(Cart cartObj)
        {
            Console.WriteLine("Add to cart confirm event triggered and captured in the Home Component : " + cartObj);

            int pos = CartList.FindIndex(item => item.ProductId == cartObj.ProductId);
            if (pos >= 0)
            {
                CartList[pos].QuantityPurchased += cartObj.QuantityPurchased;
            }
            else
            {
                CartList.Add(cartObj);
            }


        }
    }
}
